<?php

namespace App\Livewire;

use Livewire\Component;

class WelcomeDiv extends Component
{
    public function render()
    {
        return view('livewire.welcome-div');
    }
}
