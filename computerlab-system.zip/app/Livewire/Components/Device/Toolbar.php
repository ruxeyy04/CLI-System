<?php

namespace App\Livewire\Components\Device;

use Livewire\Component;

class Toolbar extends Component
{
    public function render()
    {
        return view('livewire.components.device.toolbar');
    }
}
