<?php

namespace App\Livewire\Components\Breadcrumbs;

use Livewire\Component;

class Filteraction extends Component
{
    public function render()
    {
        return view('livewire.components.breadcrumbs.filteraction');
    }
}
