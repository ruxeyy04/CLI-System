<?php

namespace App\Livewire\Components\Navbar;

use Livewire\Component;

class Search extends Component
{
    public function render()
    {
        return view('livewire.components.navbar.search');
    }
}
