<?php

namespace App\Livewire\Components\Navbar;

use Livewire\Component;

class Notification extends Component
{
    public function render()
    {
        return view('livewire.components.navbar.notification');
    }
}
