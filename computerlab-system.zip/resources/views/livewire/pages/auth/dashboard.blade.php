<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Volt\Component;

new #[Layout('layouts.assistant')] class extends Component
{

}; ?>
    <div id="kt_app_content_container" class="app-container  container-xxl ">
        <!--begin::main-->
        <div class="card bg-body pb-lg-18">
            <div class="card-body pb-lg-20">


            </div>
        </div>
        <!--end::main-->
    </div>


