<x-welcome-layout>
    <livewire:welcome-div></livewire:welcome-div>
</x-welcome-layout>
