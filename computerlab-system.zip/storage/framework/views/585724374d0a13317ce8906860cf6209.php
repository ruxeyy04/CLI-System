<?php

use Livewire\Volt\Component;

?>

<div class="card-toolbar">
    <div class="d-flex justify-content-end">
        <button type="button" class="btn btn-primary" wire:click="$dispatch('add-laboratory-modal')">
            <i class="ki-duotone ki-plus fs-2"></i> Add Laboratory
        </button>
    </div>
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/laboratory/card-toolbar.blade.php ENDPATH**/ ?>