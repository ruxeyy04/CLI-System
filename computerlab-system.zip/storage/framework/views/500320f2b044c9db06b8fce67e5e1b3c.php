<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <meta charset="utf-8" />
    <meta name="description" content="CLIS" />
    <meta name="keywords" content="computer, laboratory" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="../../assets/media/logos/favicon.ico" />

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

    <link href="../../assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
    <link href="../../assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
    <script>
        let session_id = `<?php echo e(session()->getId()); ?>`
    </script>

    <script>
        if (window.top != window.self) {
            window.top.location.replace(window.self.location.href);
        }
    </script>
    <script>
        var defaultThemeMode = "light";
        var themeMode;

        if (document.documentElement) {
            if (document.documentElement.hasAttribute("data-bs-theme-mode")) {
                themeMode = document.documentElement.getAttribute("data-bs-theme-mode");
            } else {
                if (localStorage.getItem("data-bs-theme") !== null) {
                    themeMode = localStorage.getItem("data-bs-theme");
                } else {
                    themeMode = defaultThemeMode;
                }
            }

            if (themeMode === "system") {
                themeMode = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
            }

            document.documentElement.setAttribute("data-bs-theme", themeMode);
        }
    </script>
</head>




<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="true"
    data-kt-app-sidebar-enabled="true" data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true"
    data-kt-app-sidebar-push-header="true" data-kt-app-sidebar-push-toolbar="true"
    data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true" class="app-default">
    
    <script src="../assets/plugins/global/plugins.bundle.js"></script>
    <script src="../assets/js/scripts.bundle.js"></script>
    <script>
        var currentDeviceId = null
        var cpu_util = {
            name: "Utilization",
            data: []
        }
        var cpu_temp = {
            name: "Temperature",
            data: []
        }
        var timestamps = []

        var ram_usage = {
            name: "RAM Usage",
            data: [],
            timestamps: []
            
        }
        var gpu_usage = {
            name: "Usage",
            data: []
        }
        var gpu_temp = {
            name: "Temperature",
            data: []
        }
        var gpu_timestamps = []
    </script>
    

    
    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">
        
        <div class="app-page flex-column flex-column-fluid " id="kt_app_page">


            
            <div id="kt_app_header" class="app-header ">

                
                <div class="app-container container-fluid d-flex align-items-stretch justify-content-between "
                    id="kt_app_header_container">

                    
                    <div class="d-flex align-items-center d-lg-none ms-n3 me-2" title="Show sidebar menu">
                        <div class="btn btn-icon btn-active-color-primary w-35px h-35px"
                            id="kt_app_sidebar_mobile_toggle">
                            <i class="ki-duotone ki-abstract-14 fs-1"><span class="path1"></span><span
                                    class="path2"></span></i>
                        </div>
                    </div>
                    


                    
                    <div class="d-flex align-items-center flex-grow-1 flex-lg-grow-0">
                        <a href="../index-2.html" class="d-lg-none">
                            <img alt="Logo" src="../assets/media/logos/default-small.png"
                                class="theme-light-show h-30px" />
                            <img alt="Logo" src="../assets/media/logos/default-small-dark.png"
                                class="theme-dark-show h-30px" />
                        </a>
                    </div>
                    

                    
                    <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1"
                        id="kt_app_header_wrapper">


                        
                        <div class="d-flex align-items-center">
                            <h4 class="m-0 text-muted d-none d-sm-block">Computer Laboratory Information System</h4>
                        </div>
                        


                        
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.navbar.layout', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2775466172-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        
                    </div>
                    
                </div>
                
            </div>
            
            
            <div class="app-wrapper flex-column flex-row-fluid " id="kt_app_wrapper">






                
                <div id="kt_app_sidebar" class="app-sidebar flex-column " data-kt-drawer="true"
                    data-kt-drawer-name="app-sidebar" data-kt-drawer-activate="{default: true, lg: false}"
                    data-kt-drawer-overlay="true" data-kt-drawer-width="225px" data-kt-drawer-direction="start"
                    data-kt-drawer-toggle="#kt_app_sidebar_mobile_toggle">


                    
                    <div class="px-6 app-sidebar-logo" id="kt_app_sidebar_logo">
                        
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <img alt="Logo" src="../assets/media/logos/default-dark.png"
                                class="h-30px app-sidebar-logo-default" />
                        </a>
                        

                        
                        <div id="kt_app_sidebar_toggle"
                            class="app-sidebar-toggle btn btn-icon btn-sm h-30px w-30px rotate " data-kt-toggle="true"
                            data-kt-toggle-state="active" data-kt-toggle-target="body"
                            data-kt-toggle-name="app-sidebar-minimize">

                            <i class="rotate-180 ki-duotone ki-double-left fs-2"><span class="path1"></span><span
                                    class="path2"></span></i>
                        </div>
                        
                    </div>
                    
                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.sidebar.layout', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2775466172-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    
                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.sidebar.footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2775466172-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    
                </div>
                


                
                <div class="app-main flex-column flex-row-fluid " id="kt_app_main">
                    
                    <div class="d-flex flex-column flex-column-fluid">

                        
                        <div id="kt_app_toolbar" class="py-3 app-toolbar py-lg-6 ">

                            
                            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack ">



                                
                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.breadcrumbs.layout', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2775466172-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                
                                
                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.breadcrumbs.filteraction', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2775466172-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                
                            </div>
                            
                        </div>
                        

                        
                        <div id="kt_app_content" class="app-content flex-column-fluid ">

                            <?php echo e($slot); ?>

                        </div>
                        

                    </div>
                    


                    
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2775466172-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    
                </div>
                


            </div>
            


        </div>
        
    </div>
    





</body>

<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<script src="<?php echo e(asset('js/channels.js')); ?>"></script>

<script src="<?php echo e(asset('js/charts.js')); ?>"></script>

</html>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/layouts/assistant.blade.php ENDPATH**/ ?>