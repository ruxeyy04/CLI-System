<div class="flex-wrap page-title d-flex flex-column justify-content-center me-3 ">
    <h1 class="my-0 text-gray-900 page-heading d-flex fw-bold fs-3 flex-column justify-content-center">
        <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() == 'dashboard'): ?>
            Welcome <?php echo e(Auth::user()->fname); ?>!
        <?php elseif(Request::segment(1) == 'account'): ?>
            <?php if(Route::currentRouteName() == 'account_overview'): ?>
                User Profile
            <?php elseif(Route::currentRouteName() == 'account_settings'): ?>
                Account Settings
            <?php elseif(Route::currentRouteName() == 'account_changepass'): ?>
                Change Password
            <?php elseif(Route::currentRouteName() == 'account_sessions'): ?>
                Active Sessions
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php elseif(Route::currentRouteName() == 'user_management'): ?>
            User Management
        <?php elseif(Route::currentRouteName() == 'laboratory'): ?>
            Laboratory
        <?php elseif(Route::currentRouteName() == 'computerdevices'): ?>
            Computer Devices
        <?php elseif(Route::currentRouteName() == 'notifications'): ?>
            Notifications
        <?php elseif(Route::currentRouteName() == 'devicegraph'): ?>
            Computer Device Real-Time Information
        <?php elseif(Route::currentRouteName() == 'devicelogs'): ?>
            Computer Device Logs
        <?php else: ?>
            Welcome!
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </h1>

    <ul class="pt-1 my-0 breadcrumb breadcrumb-separatorless fw-semibold fs-7">
        <li class="breadcrumb-item text-muted">
            <a href="/" class="text-muted text-hover-primary" wire:navigate>
                Home
            </a>
        </li>
        <li class="breadcrumb-item">
            <span class="bg-gray-500 bullet w-5px h-2px"></span>
        </li>

        <?php if(Route::currentRouteName() == 'devicegraph'): ?>
            <?php
                $deviceId = request()->route('id');
                $device = \App\Models\ComputerDevice::find($deviceId);
                $laboratory = $device ? $device->laboratory : null;
            ?>
            <!--[if BLOCK]><![endif]--><?php if($laboratory): ?>
                <li class="breadcrumb-item text-muted">
                    <a href="<?php echo e(route('laboratory')); ?>"
                        class="text-muted text-hover-primary"><?php echo e($laboratory->laboratory_name); ?></a>
                </li>
                <li class="breadcrumb-item">
                    <span class="bg-gray-500 bullet w-5px h-2px"></span>
                </li>
                <li class="breadcrumb-item text-muted">
                    <?php echo e($device->device_name); ?>

                </li>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php elseif(Route::currentRouteName() == 'devicelogs'): ?>
            <?php
                $deviceId = request()->route('id');
                $device = \App\Models\ComputerDevice::find($deviceId);
                $laboratory = $device ? $device->laboratory : null;
            ?>
            <!--[if BLOCK]><![endif]--><?php if($laboratory): ?>
                <li class="breadcrumb-item text-muted">
                    <a href="<?php echo e(route('laboratory')); ?>"
                        class="text-muted text-hover-primary"><?php echo e($laboratory->laboratory_name); ?></a>
                </li>
                <li class="breadcrumb-item">
                    <span class="bg-gray-500 bullet w-5px h-2px"></span>
                </li>
                <li class="breadcrumb-item text-muted">
                    <?php echo e($device->device_name); ?>

                </li>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->       
        <?php elseif(Request::segment(1) == 'account'): ?>
            <li class="breadcrumb-item text-muted">
                <a href="<?php echo e(route('account_overview')); ?>" class="text-muted text-hover-primary">Account</a>
            </li>
            <li class="breadcrumb-item">
                <span class="bg-gray-500 bullet w-5px h-2px"></span>
            </li>
            <li class="breadcrumb-item text-muted">
                <?php if(Route::currentRouteName() == 'account_overview'): ?>
                    User Profile
                <?php elseif(Route::currentRouteName() == 'account_settings'): ?>
                    Account Settings
                <?php elseif(Route::currentRouteName() == 'account_changepass'): ?>
                    Change Password
                <?php elseif(Route::currentRouteName() == 'account_sessions'): ?>
                    Active Sessions
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </li>
        <?php elseif(Route::currentRouteName() == 'user_management'): ?>
            <li class="breadcrumb-item text-muted">
                User Management
            </li>
        <?php elseif(Route::currentRouteName() == 'laboratory'): ?>
            <li class="breadcrumb-item text-muted">
                Laboratory
            </li>
        <?php elseif(Route::currentRouteName() == 'computerdevices'): ?>
            <li class="breadcrumb-item text-muted">
                Computer Devices
            </li>
            
        <?php elseif(Route::currentRouteName() == 'notifications'): ?>
            <li class="breadcrumb-item text-muted">
                Notifications
            </li>
        <?php else: ?>
            <li class="breadcrumb-item text-muted">
                Dashboard
            </li>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/breadcrumbs/layout.blade.php ENDPATH**/ ?>