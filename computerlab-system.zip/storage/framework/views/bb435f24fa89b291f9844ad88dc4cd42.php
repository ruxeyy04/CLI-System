<?php if (isset($component)) { $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772 = $attributes; } ?>
<?php $component = App\View\Components\AssistantLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('assistant-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AssistantLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_content_container" class="app-container container-xxl ">
        <?php if($device->patch_id): ?>
        <script>
             currentDeviceId = '<?php echo e($device->id); ?>';
        </script>
        <?php else: ?>
        <script>
             currentDeviceId = null;
        </script>
        <?php endif; ?>
        <div class="row gx-5 gx-xl-10 mb-xl-10">
            <!--begin::Col-->
            <div class="mb-10 col-md-6 col-lg-6 col-xl-6 col-xxl-3">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.cpu-card', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <div class="card card-flush h-md-50 mb-xl-10">
                    <!--begin::Header-->
                    <div class="pt-5 card-header">
                        <!--begin::Title-->
                        <div class="card-title d-flex flex-column">
                            <!--begin::Info-->
                            <div class="d-flex align-items-center">
                                <!--begin::Amount-->
                                <span class="text-gray-900 fs-2hx fw-bold me-2 lh-1 ls-n2">Storage</span>
                                <!--end::Amount-->
                            </div>
                            <!--end::Info-->

                            <!--begin::Subtitle-->
                            <span class="pt-1 text-gray-500 fw-semibold fs-6">Disk Information</span>
                            <!--end::Subtitle-->
                        </div>
                        <!--end::Title-->
                    </div>
                    <!--end::Header-->

                    <!--begin::Card body-->
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.disk-card-summary', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <!--end::Card body-->
                </div>
                <!--end::Card widget 5-->
            </div>
            <!--end::Col-->

            <!--begin::Col-->
            <div class="mb-10 col-md-6 col-lg-6 col-xl-6 col-xxl-3">
                <!--begin::Card widget 6-->
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.ram-card', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.gpu-card', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>
            <!--end::Col-->

            <!--begin::Col-->
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.cpugraph', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <!--end::Col-->
        </div>
        <div class="row gx-5 gx-xl-10 mb-xl-10">
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.ramgraph', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.gpugraph', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <div class="row gx-5 gx-xl-10 mb-xl-10">
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.disk-cards', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.input-devices', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <!--end::Row-->
    </div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.modal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.trend-modal', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-10', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.computer.view-trend-modal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-542103793-11', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $attributes = $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $component = $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/devicegraph.blade.php ENDPATH**/ ?>