<div class="pt-0 card-body">
    
    <!--begin::Progress-->
    <!--[if BLOCK]><![endif]--><?php if(isset($disks)): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $disks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Calculate disk usage percentage
                $usagePercentage = round(($disk->used / $disk->total) * 100);
                $barColor = $usagePercentage > 90 ? 'danger' : 'success'; // Change color based on usage
            ?>

            <div class="mt-3 d-flex align-items-center flex-column w-100">
                <div class="mt-auto mb-2 d-flex justify-content-between w-100">
                    <span class="text-gray-900 fw-bolder fs-6"><?php echo e($disk->volume_label); ?> <?php echo e($disk->mountpoint); ?>\</span>
                    <span class="text-gray-500 fw-bold fs-6"><?php echo e($usagePercentage); ?>%</span>
                </div>

                <div class="mx-3 rounded h-8px w-100 bg-light-<?php echo e($barColor); ?>">
                    <div class="rounded bg-<?php echo e($barColor); ?> h-8px" role="progressbar"
                        style="width: <?php echo e($usagePercentage); ?>%;" aria-valuenow="<?php echo e($usagePercentage); ?>" aria-valuemin="0"
                        aria-valuemax="100"></div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    <?php else: ?>
        <div class="d-flex flex-column content-justify-center w-100">
            <h4>No Data</h4>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--end::Progress-->
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/computer/disk-card-summary.blade.php ENDPATH**/ ?>