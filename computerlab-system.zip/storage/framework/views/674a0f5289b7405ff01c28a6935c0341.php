<?php

use Livewire\Volt\Component;
use App\Models\User;
use App\Models\Laboratory;
use Livewire\Attributes\Validate;
use Illuminate\Validation\Rule;

?>

<div class="modal fade" id="addlab_modal" tabindex="-1" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog mw-500px">
        <div class="modal-content">
            <div class="modal-header" id="addlab_modal_header">
                <h2 class="fw-bold">Add Laboratory</h2>
                <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <i class="ki-duotone ki-cross fs-1"><span class="path1"></span><span class="path2"></span></i>
                </div>
            </div>
            <div class="px-5 modal-body my-7">
                <div class="px-5 d-flex flex-column px-lg-10" wire:ignore.self>
                    <form action="">
                        <div class="fv-row mb-7">
                            <label class="mb-2 required fw-semibold fs-6">Laboratory Name</label>
                            <input type="text" name="laboratory_name"
                                class="mb-3 form-control form-control-solid mb-lg-0" placeholder="Laboratory Name"
                                wire:model.live='laboratory_name' />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['laboratory_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="fv-row mb-7">
                            <label class="mb-2 required fw-semibold fs-6">Capacity</label>
                            <input type="number" name="capacity" class="mb-3 form-control form-control-solid mb-lg-0"
                                placeholder="Capacity" wire:model.live='capacity' autocomplete="off"/>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-10">
                            <div class="mb-2 fs-6 fw-semibold required">Select Computer Lab Assistant</div>
                            <input type="text" autocomplete="off"
                                class="mb-4 form-control form-control-solid flex-grow-1" name="search"
                                placeholder="Search User" wire:model.live='searchVal'>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedUsers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="mh-250px scroll-y">
                                <?php
                                    $colors = [
                                        ['bg-light-danger', 'text-danger'],
                                        ['bg-light-success', 'text-success'],
                                        ['bg-light-info', 'text-info'],
                                        ['bg-light-warning', 'text-warning'],
                                        ['bg-light-primary', 'text-primary'],
                                    ];
                                ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $assistants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assistant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $randomColor = $colors[array_rand($colors)];
                                    ?>
                                    <div
                                        class="py-4 border-gray-300 d-flex flex-stack border-bottom border-bottom-dashed">
                                        <!--begin::Details-->
                                        <div class="d-flex align-items-center">
                                            <!--begin::Avatar-->
                                            <div class="symbol symbol-35px symbol-circle" wire:ignore>
                                                <!--[if BLOCK]><![endif]--><?php if($assistant->profileimg): ?>
                                                    <img alt="<?php echo e($assistant->fname); ?> <?php echo e($assistant->lname); ?>"
                                                        src="<?php echo e(asset('storage/profile/' . $assistant->id . '/' . $assistant->profileimg)); ?>">
                                                <?php else: ?>
                                                    <div
                                                        class="symbol-label fs-3 <?php echo e($randomColor[0]); ?> <?php echo e($randomColor[1]); ?>">
                                                        <?php echo e(strtoupper($assistant->fname[0])); ?>

                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </div>
                                            <!--end::Avatar-->

                                            <!--begin::Details-->
                                            <div class="ms-5">
                                                <a href="#"
                                                    class="mb-2 text-gray-900 fs-5 fw-bold text-hover-primary">
                                                    <?php echo e($assistant->fname); ?> <?php echo e($assistant->lname); ?>

                                                </a>
                                                <div class="fw-semibold text-muted"><?php echo e($assistant->email); ?></div>
                                            </div>
                                        </div>
                                        <div class="me-3">
                                            <input wire:key="assistant-<?php echo e($assistant->id); ?>"
                                                class="form-check-input h-20px w-20px" type="checkbox"
                                                name="selecteduser[]" value="<?php echo e($assistant->id); ?>"
                                                wire:model.live="selectedUsers"
                                                <?php if(in_array($assistant->id, $selectedUsers)): ?> checked <?php else: ?> <?php endif; ?>>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>



                    </form>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                    wire:click='discardForm'>Discard</button>
                <button type="button" class="btn btn-primary" wire:click='saveLaboratory' wire:loading.attr='disabled'
                    wire:target="saveLaboratory">
                    <span wire:loading.remove wire:target="saveLaboratory">Save Laboratory</span>
                    <span wire:loading wire:target="saveLaboratory">
                        Please wait... <span class="align-middle spinner-border spinner-border-sm ms-2"></span>
                    </span>

                </button>
            </div>
        </div>

    </div>
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/laboratory/add-modal.blade.php ENDPATH**/ ?>