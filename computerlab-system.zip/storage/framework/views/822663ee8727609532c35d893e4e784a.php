<div class="card-toolbar">
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
        <div class="d-flex justify-content-end">
            <button type="button" class="btn btn-primary" wire:click="$dispatch('add-device-modal')">
                <i class="ki-duotone ki-plus fs-2"></i> Add Device
            </button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/device/toolbar.blade.php ENDPATH**/ ?>