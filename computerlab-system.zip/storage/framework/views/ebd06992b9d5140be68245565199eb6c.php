<?php

use App\Livewire\Forms\LoginForm;
use Illuminate\Support\Facades\Session;
use Livewire\Attributes\Layout;
use Livewire\Volt\Component;

?>

<div>

</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/pages/counter.blade.php ENDPATH**/ ?>