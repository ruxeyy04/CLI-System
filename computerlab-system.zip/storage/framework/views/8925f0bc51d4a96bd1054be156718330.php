<?php

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Livewire\Attributes\Layout;
use Livewire\Volt\Component;
use Livewire\WithFileUploads;
use Livewire\Attributes\Validate;

?>

<div class="mb-5 card mb-xl-10">
    <!--begin::Card header-->
    <div class="border-0 cursor-pointer card-header" role="button" data-bs-toggle="collapse"
        data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
        <!--begin::Card title-->
        <div class="m-0 card-title">
            <h3 class="m-0 fw-bold">Profile Details</h3>
        </div>
        <!--end::Card title-->
    </div>
    <!--begin::Card header-->
    <!--begin::Content-->
    <div class="collapse show" id="kt_account_profile_details">
        <!--begin::Form-->
        <form class="form fv-plugins-bootstrap5 fv-plugins-framework" wire:submit="updateProfileInformation"
            enctype="multipart/form-data">
            <!--begin::Card body-->
            <div class="card-body border-top p-9">
                <!--begin::Input group-->
                <div class="mb-6 row">
                    <!--begin::Label-->
                    <label class="col-lg-4 col-form-label fw-semibold fs-6">Avatar</label>
                    <!--end::Label-->

                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <!--begin::Image input-->
                        <div class="image-input image-input-outline <?php echo e($existProfileImg ? '' : 'image-input-empty'); ?>"
                            data-kt-image-input="true" wire:ignore
                            style="background-image: url('<?php echo e(asset('storage/profile/default.jpg')); ?>')">
                            <!--begin::Preview existing avatar-->
                            <div class="image-input-wrapper w-125px h-125px"
                                style="background-image: <?php echo e($existProfileImg ? "url('" . asset('storage/profile/' . Auth::user()->id . '/' . $existProfileImg) . "')" : 'none'); ?>;');">
                            </div>
                            <!--end::Preview existing avatar-->

                            <!--begin::Label-->
                            <label class="shadow btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body"
                                data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change avatar">
                                <i class="ki-duotone ki-pencil fs-7"><span class="path1"></span><span
                                        class="path2"></span></i>
                                <!--begin::Inputs-->
                                <input type="file" wire:model="profileimg" name="profileimg"
                                    accept=".png, .jpg, .jpeg" />
                                <input type="hidden" name="avatar_remove" />
                                <!--end::Inputs-->
                            </label>
                            <!--end::Label-->

                            <!--begin::Cancel-->
                            <span class="shadow btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body"
                                data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel avatar"
                                wire:click='cancelImage'>
                                <i class="ki-duotone ki-cross fs-2"><span class="path1"></span><span
                                        class="path2"></span></i> </span>
                            <!--end::Cancel-->


                            <!--begin::Remove-->
                            <span class="shadow btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body"
                                data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove avatar"
                                wire:click='removeProfileImage'>
                                <i class="ki-duotone ki-trash-square fs-2">
                                    <span class="path1"></span>
                                    <span class="path2"></span>
                                    <span class="path3"></span>
                                    <span class="path4"></span>
                                </i> </span>
                            <!--end::Remove-->
                        </div>
                        <!--end::Image input-->

                        <!--begin::Hint-->
                        <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
                        <!--end::Hint-->

                        <div
                            class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['profileimg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <!--end::Col-->
                </div>
                <!--end::Input group-->


                <div class="mb-6 row">
                    <!-- First Name -->
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">First Name</label>
                    <div class="col-lg-8">
                        <input type="text" name="fname" class="form-control form-control-lg form-control-solid"
                            placeholder="First Name" wire:model="fname" wire:keydown="checkForChanges">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div
                                class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">

                                <?php echo e($message); ?>


                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                </div>

                <div class="mb-6 row">
                    <!-- Middle Name -->
                    <label class="col-lg-4 col-form-label fw-semibold fs-6">Middle Name</label>
                    <div class="col-lg-8">
                        <input type="text" name="midname" class="form-control form-control-lg form-control-solid"
                            placeholder="Middle Name" wire:model="midname" wire:keydown="checkForChanges">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['midname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div
                                class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">

                                <?php echo e($message); ?>


                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                </div>

                <div class="mb-6 row">
                    <!-- Last Name -->
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">Last Name</label>
                    <div class="col-lg-8">
                        <input type="text" name="lname" class="form-control form-control-lg form-control-solid"
                            placeholder="Last Name" wire:model="lname" wire:keydown="checkForChanges">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div
                                class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">

                                <?php echo e($message); ?>


                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="mb-6 row">
                    <!-- Username -->
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">Username</label>
                    <div class="col-lg-8">
                        <input type="text" name="username" class="form-control form-control-lg form-control-solid"
                            placeholder="Username" wire:model="username" wire:keydown="checkForChanges">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div
                                class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">

                                <?php echo e($message); ?>


                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="mb-6 row">
                    <!-- Motto -->
                    <label class="col-lg-4 col-form-label fw-semibold fs-6">Motto</label>
                    <div class="col-lg-8">
                        <input type="text" name="motto" class="form-control form-control-lg form-control-solid"
                            placeholder="Motto" wire:model="motto" wire:keydown="checkForChanges">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['motto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div
                                class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">

                                <?php echo e($message); ?>


                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Card Footer -->

            </div>
            <!--end::Card body-->
            <div class="py-6 card-footer d-flex justify-content-end px-9">
                <!--[if BLOCK]><![endif]--><?php if($hasUnsavedChanges): ?>
                    <button type="button" wire:loading.attr='disabled'
                        class="btn btn-light btn-active-light-primary me-2" wire:click="discardChanges"
                        wire:target="discardChanges">
                        <span wire:loading.remove wire:target="discardChanges">Discard</span>
                        <span wire:loading wire:target="discardChanges">
                            Please wait... <span class="align-middle spinner-border spinner-border-sm ms-2"></span>
                        </span>
                    </button>
                    <button type="submit" class="btn btn-primary" wire:loading.attr='disabled'
                        wire:target="updateProfileInformation">
                        <span wire:loading.remove wire:target="updateProfileInformation">Save Changes</span>
                        <span wire:loading wire:target="updateProfileInformation">
                            Please wait... <span class="align-middle spinner-border spinner-border-sm ms-2"></span>
                        </span>
                    </button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>
        </form>
        <!--end::Form-->

    </div>
    <!--end::Content-->
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/profile/profile_settings.blade.php ENDPATH**/ ?>