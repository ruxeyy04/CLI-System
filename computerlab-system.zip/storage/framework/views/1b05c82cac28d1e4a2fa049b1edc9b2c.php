<?php if (isset($component)) { $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772 = $attributes; } ?>
<?php $component = App\View\Components\AssistantLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('assistant-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AssistantLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_content_container" class="app-container container-xxl ">
        <!--begin::Card-->
        <div class="card">
            <div class="pt-6 border-0 card-header">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-194304831-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.toolbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-194304831-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="py-4 card-body">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.table', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-194304831-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.addmodal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-194304831-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.editmodal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-194304831-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $attributes = $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $component = $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/computerdevices.blade.php ENDPATH**/ ?>