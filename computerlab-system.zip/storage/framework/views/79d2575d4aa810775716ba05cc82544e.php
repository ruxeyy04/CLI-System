<div>
    <div class="table-responsive">
        <table class="table align-middle table-row-dashed fs-6 gy-5" id="table_data_users" wire:ignore.self>
            <thead wire:ignore>
                <tr class="text-start text-muted fw-bold fs-7 text-uppercase gs-0">
                    <th class="min-w-125px">User</th>
                    <th class="min-w-125px">Role</th>
                    <th class="min-w-125px">Last login</th>
                    <th class="min-w-125px">Verified Email </th>
                    <th class="min-w-125px">Joined Date</th>
                    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
                    <th class="text-end min-w-100px">Actions</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                 
                   
                </tr>
            </thead>
            <tbody class="text-gray-600 fw-semibold">
                <?php
                    $colors = [
                        ['bg-light-danger', 'text-danger'],
                        ['bg-light-success', 'text-success'],
                        ['bg-light-info', 'text-info'],
                        ['bg-light-warning', 'text-warning'],
                        ['bg-light-primary', 'text-primary'],
                    ];
                ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $randomColor = $colors[array_rand($colors)];
                    ?>
                    <tr wire:key="user-<?php echo e($user->id); ?>">
                        <td class="d-flex align-items-center">
                            <div class="overflow-hidden symbol symbol-circle symbol-50px me-3">
                                <a href="#!">
                                    <!--[if BLOCK]><![endif]--><?php if($user->profileimg): ?>
                                        <div class="symbol-label">
                                            <img src="<?php echo e(asset('storage/profile/' . $user->id . '/' . $user->profileimg)); ?>"
                                                alt="<?php echo e($user->fname); ?> <?php echo e($user->lname); ?>" class="w-100" />
                                        </div>
                                    <?php else: ?>
                                        <div class="symbol-label fs-3 <?php echo e($randomColor[0]); ?> <?php echo e($randomColor[1]); ?>">
                                            <?php echo e(strtoupper($user->fname[0])); ?>

                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </a>
                            </div>
                            <div class="d-flex flex-column">
                                <a href="#!" class="mb-1 text-gray-800 text-hover-primary"><?php echo e($user->fname); ?>

                                    <?php echo e($user->lname); ?></a>
                                <span><?php echo e($user->email); ?></span>
                            </div>
                        </td>
                        <td>
                            <?php echo e(ucfirst($user->role)); ?>

                        </td>
                        <td>
                            <div class="badge badge-light fw-bold">
                                <?php echo e($user->last_login ? $user->last_login->diffForHumans() : 'Never'); ?></div>
                        </td>
                        <td>
                            <div
                                class="badge badge-light-<?php echo e($user->email_verified_at ? 'success' : 'danger'); ?> fw-bold">
                                <?php echo e($user->email_verified_at ? 'Verified' : 'Not Verified'); ?></div>
                        </td>
                        <td>
                            <?php echo e($user->created_at ? $user->created_at->format('d M Y, h:i a') : 'N/A'); ?>

                        </td>
                        <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
                        <td class="text-end">
                            <!--[if BLOCK]><![endif]--><?php if($user->id != Auth::id()): ?>
                                <button class="btn btn-light btn-active-light-primary btn-flex btn-center btn-sm"
                                    data-bs-toggle="dropdown" aria-expanded="false"
                                    wire:key="user-<?php echo e($user->id); ?>">
                                    Actions
                                    <i class="ki-duotone ki-down fs-5 ms-1"></i>
                                </button>
                                <div class="py-4 dropdown-menu dropdown-menu-end menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-150px"
                                    wire:ignore>
                                    <div class="px-3 menu-item">
                                        <a href="#" class="px-3 menu-link"
                                            wire:click='resetPasswordConfirmation(<?php echo e($user->id); ?>)'>
                                            Reset Password
                                        </a>
                                    </div>
                                    <div class="px-3 menu-item">
                                        <a href="#" class="px-3 menu-link"
                                            wire:click='openEditModal(<?php echo e($user->id); ?>)'>
                                            Edit
                                        </a>
                                    </div>
                                    <div class="px-3 menu-item">
                                        <a href="#" class="px-3 menu-link"
                                            wire:click='deleteUserConfirmation(<?php echo e($user->id); ?>)'>
                                            Delete
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        </td>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                     
                       
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <div class="row">
        <div
            class="col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start dt-toolbar">
            <!-- Add any toolbar items here -->
        </div>
        <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
            <div class="dt-paging paging_simple_numbers">
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/users/userstable.blade.php ENDPATH**/ ?>