<div class="mb-5 card card-flush h-md-50 mb-xl-10">
    <pre><?php echo e(json_encode($device, JSON_PRETTY_PRINT)); ?></pre>
    <div class="pt-5 card-header">
        <div class="card-title d-flex flex-column">
            <div class="d-flex align-items-center">
                <span class="text-gray-900 fs-2hx fw-bold me-2 lh-1 ls-n2">CPU</span>
            </div>
            <span class="pt-1 text-gray-500 fw-semibold fs-6">Central Processing Unit</span>
        </div>
    </div>
    <div class="pt-2 pb-4 card-body d-flex align-items-center">
        
        
    </div>
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/computer/cpu-card.blade.php ENDPATH**/ ?>