<?php if (isset($component)) { $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772 = $attributes; } ?>
<?php $component = App\View\Components\AssistantLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('assistant-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AssistantLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_content_container" class="app-container  container-xxl ">
        <!--begin::main-->
        <div class="card bg-body pb-lg-18">
            <div class="card-body pb-lg-20">


            </div>
        </div>
        <!--end::main-->
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $attributes = $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $component = $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/dashboard.blade.php ENDPATH**/ ?>