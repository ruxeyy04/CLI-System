<?php

use Livewire\Volt\Component;
use App\Models\GpuInfo;
use Livewire\Attributes\On;

?>

<div class="card card-flush h-md-50 mb-xl-10">
    <div class="pt-5 card-header">
        <div class="card-title d-flex flex-column">
            <span class="text-gray-900 fs-2hx fw-bold me-2 lh-1 ls-n2">GPU</span>
            <span class="pt-1 text-gray-500 fw-semibold fs-6">Graphic Processing Unit</span>
        </div>
    </div>
    <div class="pt-2 pb-4 card-body d-flex align-items-center">
        <!--[if BLOCK]><![endif]--><?php if($gpuInfo): ?>
            <div class="d-flex flex-column content-justify-center w-100">
                <div class="d-flex fs-6 fw-semibold align-items-center">
                    <div class="bullet w-8px h-6px rounded-2 bg-success me-3"></div>
                    <div class="text-gray-500 flex-grow-1 me-4">Brand</div>
                    <div class="text-gray-700 fw-bolder text-xxl-end"><?php
                        $brand = $gpuInfo->brand;
                        $uniqueBrand = implode(' ', array_unique(explode(' ', $brand)));
                    ?>
                    
                    <?php echo e($uniqueBrand); ?>

                    </div>
                </div>
                <div class="d-flex fs-6 fw-semibold align-items-center">
                    <div class="bullet w-8px h-6px rounded-2 bg-danger me-3"></div>
                    <div class="text-gray-500 flex-grow-1 me-4">Temperature</div>
                    <div class="text-gray-700 fw-bolder text-xxl-end"><?php echo e($gpuInfo->temp); ?> °C</div>
                </div>
                <div class="d-flex fs-6 fw-semibold align-items-center">
                    <div class="bullet w-8px h-6px rounded-2 bg-warning me-3"></div>
                    <div class="text-gray-500 flex-grow-1 me-4">Usage</div>
                    <div class="text-gray-700 fw-bolder text-xxl-end"><?php echo e($gpuInfo->usage); ?> %</div>
                </div>
                <div class="d-flex fs-6 fw-semibold align-items-center">
                    <div class="bullet w-8px h-6px rounded-2 bg-primary me-3"></div>
                    <div class="text-gray-500 flex-grow-1 me-4">Power</div>
                    <div class="text-gray-700 fw-bolder text-xxl-end"><?php echo e(round($gpuInfo->power, 2)); ?>W</div>
                </div>
                <div class="d-flex fs-6 fw-semibold align-items-center">
                    <div class="bullet w-8px h-6px rounded-2 bg-success me-3"></div>
                    <div class="text-gray-500 flex-grow-1 me-4">GPU Memory</div>
                    <div class="text-gray-700 fw-bolder text-xxl-end"><?php echo e($gpuInfo->memory); ?> MB</div>
                </div>
            </div>
        <?php else: ?>
            <div class="d-flex flex-column content-justify-center w-100">
                <h4>No Data</h4>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/computer/gpu-card.blade.php ENDPATH**/ ?>