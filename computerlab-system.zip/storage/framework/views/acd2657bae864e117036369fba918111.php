<?php

use Livewire\Attributes\Layout;
use Livewire\Volt\Component;
use App\Models\User;
use App\Models\Laboratory;
use App\Models\ComputerDevice;

?>

<div id="kt_app_content_container" class="app-container container-xxl">
    <div class="row">
        <!--[if BLOCK]><![endif]--><?php if(ucfirst(auth()->user()->role) === 'Incharge'): ?>
            <div class="col-md-3">
                <div class="card h-lg-100">
                    <div class="card-body d-flex justify-content-between align-items-start flex-column">
                        <div class="card-title d-flex flex-column">
                            <span class="text-gray-900 fs-2hx fw-bold lh-1 ls-n2">Total Devices</span>
                        </div>
                        <div class="d-flex flex-column my-7">
                            <span class="text-gray-800 fw-semibold fs-3x lh-1 ls-n2"><?php echo e($this->totalDevices); ?></span>
                            <span class="text-gray-500 fw-semibold fs-6">Devices</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card h-lg-100">
                    <div class="card-body d-flex justify-content-between align-items-start flex-column">
                        <div class="card-title d-flex flex-column">
                            <span class="text-gray-900 fs-2hx fw-bold lh-1 ls-n2">Total Laboratories</span>
                        </div>
                        <div class="d-flex flex-column my-7">
                            <span class="text-gray-800 fw-semibold fs-3x lh-1 ls-n2"><?php echo e($totalLaboratories); ?></span>
                            <span class="text-gray-500 fw-semibold fs-6">Laboratories</span>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif(ucfirst(auth()->user()->role) === 'Assistant'): ?>
            <div class="col-md-3">
                <div class="card h-lg-100">
                    <div class="card-body d-flex justify-content-between align-items-start flex-column">
                        <div class="card-title d-flex flex-column">
                            <span class="text-gray-900 fs-2hx fw-bold lh-1 ls-n2">Total Devices</span>
                        </div>
                        <div class="d-flex flex-column my-7">
                            <span class="text-gray-800 fw-semibold fs-3x lh-1 ls-n2"><?php echo e($this->totalDevicesInLab); ?></span>
                            <span class="text-gray-500 fw-semibold fs-6">Devices in Your Laboratory</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card h-lg-100">
                    <div class="card-body d-flex justify-content-between align-items-start flex-column">
                        <div class="card-title d-flex flex-column">
                            <span class="text-gray-900 fs-2hx fw-bold lh-1 ls-n2">Laboratory Info</span>
                        </div>
                        <div class="d-flex flex-column my-7">
                            <span class="text-gray-800 fw-semibold fs-3x lh-1 ls-n2"><?php echo e($this->assignedLabName); ?></span>
                            <span class="text-gray-500 fw-semibold fs-6">Lab Name</span>
                            <span class="text-gray-800 fw-semibold fs-4 lh-1 ls-n2">Capacity: <?php echo e($this->assignedLabCapacity); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="col-md-3">
            <div class="card h-lg-100">
                <div class="card-body d-flex justify-content-between align-items-start flex-column">
                    <div class="card-title d-flex flex-column">
                        <span class="text-gray-900 fs-2hx fw-bold lh-1 ls-n2">Date</span>
                    </div>
                    <div class="d-flex flex-column my-7">
                        <span class="text-gray-800 fw-semibold fs-3x lh-1 ls-n2" id="current-date"></span>
                        <span class="text-gray-500 fw-semibold fs-6">Today's Date</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card h-lg-100">
                <div class="card-body d-flex justify-content-between align-items-start flex-column">
                    <div class="card-title d-flex flex-column">
                        <span class="text-gray-900 fs-2hx fw-bold lh-1 ls-n2">Time</span>
                    </div>
                    <div class="d-flex flex-column my-7">
                        <span class="text-gray-800 fw-semibold fs-3x lh-1 ls-n2" id="current-time"></span>
                        <span class="text-gray-500 fw-semibold fs-6">Current Time</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Livewire Components for Device Management -->
    <h1 class="mt-5">List of Device</h1>
    <div class="card mt-7">
        <div class="pt-6 border-0 card-header">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.toolbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
        <div class="py-4 card-body">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.device.table', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(ucfirst(auth()->user()->role) === 'Incharge'): ?>
        <!-- Livewire Components for Device Management -->
        <h1 class="mt-5">List of Users</h1>
        
        <div class="card mt-7">
            <div class="pt-6 border-0 card-header">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.users.users-table-search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.users.card-toolbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="py-4 card-body">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.users.userstable', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <h1 class="mt-5">List of Laboratories</h1>
        <div class="mb-4 card">
            <div class="py-3 border-0 card-header">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.card-list', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-787475154-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>


<script>
    // JavaScript to display the current date and time
    function updateDateTime() {
        const now = new Date();
        document.getElementById('current-date').textContent = now.toLocaleDateString();
        document.getElementById('current-time').textContent = now.toLocaleTimeString();
    }
    setInterval(updateDateTime, 1000); // Update every second
    updateDateTime(); // Initial call
</script><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/pages/dashboard.blade.php ENDPATH**/ ?>