<?php

use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Livewire\Attributes\Layout;
use Livewire\Volt\Component;

?>

<div>
    <div class="p-10 w-lg-500px">
        <form class="form w-100" wire:submit.prevent="register">

            <!-- Heading -->
            <div class="text-center mb-11">
                <h1 class="mb-3 text-gray-900 fw-bolder">Sign Up</h1>
            </div>

            <!-- First Name Field -->
            <div class="mb-8 fv-row">
                <input type="text" placeholder="First Name" name="fname" autocomplete="off"
                       class="bg-transparent form-control" wire:model="fname" />

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Last Name Field -->
            <div class="mb-8 fv-row">
                <input type="text" placeholder="Last Name" name="lname" autocomplete="off"
                       class="bg-transparent form-control" wire:model="lname" />

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Username Field -->
            <div class="mb-8 fv-row">
                <input type="text" placeholder="Username" name="username" autocomplete="off"
                       class="bg-transparent form-control" wire:model="username" />

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Email Field -->
            <div class="mb-8 fv-row">
                <input type="text" placeholder="Email" name="email" autocomplete="off"
                       class="bg-transparent form-control" wire:model="email" />

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Password Field -->
            <div class="mb-8 fv-row">
                <input type="password" placeholder="Password" name="password" autocomplete="off"
                       class="bg-transparent form-control" wire:model="password" />

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Confirm Password Field -->
            <div class="mb-3 fv-row">
                <input type="password" placeholder="Confirm Password" name="password_confirmation" autocomplete="off"
                       class="bg-transparent form-control" wire:model="password_confirmation" />

                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Submit Button -->
            <div class="mb-10 d-grid">
                <button type="submit" id="kt_sign_in_submit" class="btn btn-primary" 
                        wire:loading.attr="disabled">
                    <!-- Loading spinner during form submission -->
                    <span wire:loading.remove class="indicator-label">Sign Up</span>
                    <span wire:loading>
                        Please wait... <span class="align-middle spinner-border spinner-border-sm ms-2"></span>
                    </span>
                </button>
            </div>
        </form>

        <!-- Sign In Link -->
        <div class="text-center text-gray-500 fw-semibold fs-6">
            Already have an Account?
            <a href="/login" class="link-primary" wire:navigate>
                Sign in
            </a>
        </div>
    </div>
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/pages/auth/register.blade.php ENDPATH**/ ?>