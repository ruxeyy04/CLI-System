<?php

use Livewire\Attributes\Layout;
use Livewire\Volt\Component;

?>

<div id="kt_app_content_container" class="app-container  container-xxl">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.profile.usercardheader', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3030906730-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.profile.navitems', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3030906730-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.profile.profile_settings', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3030906730-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.profile.profile_contact', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3030906730-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    

</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/pages/profile/settings.blade.php ENDPATH**/ ?>