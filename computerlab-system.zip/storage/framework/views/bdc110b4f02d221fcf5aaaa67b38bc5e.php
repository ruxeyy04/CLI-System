<?php

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Livewire\Volt\Component;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Hash;
use Livewire\Attributes\Validate;

?>

<div class="mb-5 card mb-xl-10">
    
    <div class="border-0 cursor-pointer card-header" role="button" data-bs-toggle="collapse"
        data-bs-target="#contactInfoContainer">
        <div class="m-0 card-title">
            <h3 class="m-0 fw-bold">Contact Information</h3>
        </div>
    </div>
    

    
    <div id="contactInfoContainer" class="collapse show">
        
        <div class="card-body border-top p-9">
            
            <div class="flex-wrap d-flex align-items-center" x-data="{ showForm: <?php if ((object) ('showForm') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showForm'->value()); ?>')<?php echo e('showForm'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showForm'); ?>')<?php endif; ?> }">
                
                <div :class="showForm ? 'd-none' : ''">
                    <div class="mb-1 fs-6 fw-bold">Email Address</div>
                    <div class="text-gray-600 fw-semibold" x-data="<?php echo e(json_encode(['email' => auth()->user()->email])); ?>"
                        x-on:email-update.window="email = $event.detail.email;" x-text="email"></div>
                </div>
                

                
                <div :class="showForm ? '' : 'd-none'" class="flex-row-fluid">
                    
                    <form class="form" wire:submit="updateEmailSubmit">
                        <div class="mb-6 row">
                            <div class="mb-4 col-lg-6 mb-lg-0">
                                <div class="mb-0 fv-row">
                                    <label for="emailaddress" class="mb-3 form-label fs-6 fw-bold">Enter New
                                        Email
                                        Address</label>
                                    <input type="text" class="form-control form-control-lg form-control-solid"
                                        placeholder="Email Address" name="email" wire:model.live="email" />
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-0 fv-row">
                                    <label for="confirmemailpassword" class="mb-3 form-label fs-6 fw-bold">Confirm
                                        Password</label>
                                    <input type="password" name="current_password"
                                        class="form-control form-control-lg form-control-solid"
                                        wire:model.live="current_password" />
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex">
                            <button type="submit" class="px-6 btn btn-primary me-2" wire:loading.attr='disabled'
                                wire:target="updateEmailSubmit">
                                <span wire:loading.remove wire:target="updateEmailSubmit">Update Email</span>
                                <span wire:loading wire:target="updateEmailSubmit">
                                    Please wait... <span
                                        class="align-middle spinner-border spinner-border-sm ms-2"></span>
                                </span>
                            </button>
                            <button type="button" class="px-6 btn btn-color-gray-500 btn-active-light-primary"
                                wire:click="changeEmail">Cancel</button>
                        </div>
                    </form>
                    
                </div>
                

                
                <div class="ms-auto" :class="showForm ? 'd-none' : ''">
                    <button class="btn btn-light btn-active-light-primary" wire:click="changeEmail">Change
                        Email</button>
                </div>
                
            </div>
            

            
            <div class="my-6 separator separator-dashed"></div>
            

            
            <div class="flex-wrap d-flex align-items-center" x-data="{ showFormPhone: <?php if ((object) ('showFormPhone') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showFormPhone'->value()); ?>')<?php echo e('showFormPhone'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showFormPhone'); ?>')<?php endif; ?> }">
                
                <div :class="showFormPhone ? 'd-none' : ''">
                    <div class="mb-1 fs-6 fw-bold">Phone Number</div>
                    <div class="text-gray-600 fw-semibold" x-data="{ phone: '<?php echo e(Auth::user()->phone ? Auth::user()->phone : 'None'); ?>' }"
                        x-on:phone-update.window="phone = $event.detail.phone;" x-text="phone"></div>
                </div>
                

                
                <div :class="showFormPhone ? '' : 'd-none'" class="flex-row-fluid">
                    
                    <form class="form" wire:submit="updatePhoneSubmit">
                        <div class="mb-6 row">
                            <div class="mb-4 col-lg-6 mb-lg-0">
                                <div class="mb-0 fv-row">
                                    <label for="phone_number" class="mb-3 form-label fs-6 fw-bold">Enter New Phone
                                        Number</label>
                                    <input type="text" class="form-control form-control-lg form-control-solid"
                                        placeholder="Phone Number" name="phone_number" wire:model.live="phone_number" />
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-0 fv-row">
                                    <label for="confirmemailpassword" class="mb-3 form-label fs-6 fw-bold">Confirm
                                        Password</label>
                                    <input type="password" name="current_password"
                                        class="form-control form-control-lg form-control-solid"
                                        wire:model.live="current_password" />
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex">
                            <button type="submit" class="px-6 btn btn-primary me-2" wire:loading.attr='disabled'
                                wire:target="updatePhoneSubmit">
                                <span wire:loading.remove wire:target="updatePhoneSubmit">Update Phone Number</span>
                                <span wire:loading wire:target="updatePhoneSubmit">
                                    Please wait... <span
                                        class="align-middle spinner-border spinner-border-sm ms-2"></span>
                                </span>
                            </button>
                            <button type="button" class="px-6 btn btn-color-gray-500 btn-active-light-primary"
                                wire:click="changePhoneNumber">Cancel</button>
                        </div>
                    </form>
                    
                </div>
                

                
                <div class="ms-auto" :class="showFormPhone ? 'd-none' : ''">
                    <button class="btn btn-light btn-active-light-primary" wire:click="changePhoneNumber">Change
                        Phone Number</button>
                </div>
                
            </div>
            
            
            <div class="my-6 separator separator-dashed"></div>

            
            
            <div class="flex-wrap d-flex align-items-center" x-data="{ showFormAddress: <?php if ((object) ('showFormAddress') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showFormAddress'->value()); ?>')<?php echo e('showFormAddress'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showFormAddress'); ?>')<?php endif; ?> }">
                
                <div :class="showFormAddress ? 'd-none' : ''">
                    <div class="mb-1 fs-6 fw-bold">Address</div>
                    <div class="text-gray-600 fw-semibold" x-data="{ address: '<?php echo e(Auth::user()->address ? Auth::user()->address : 'None'); ?>' }"
                        x-on:address-update.window="address = $event.detail.address;" x-text="address"></div>
                </div>
                

                
                <div :class="showFormAddress ? '' : 'd-none'" class="flex-row-fluid">
                    
                    <form class="form" wire:submit="updateAddressSubmit">
                        <div class="mb-6 row">
                            <div class="mb-4 col-lg-6 mb-lg-0">
                                <div class="mb-0 fv-row">
                                    <label for="address" class="mb-3 form-label fs-6 fw-bold">Enter New
                                        Address</label>
                                    <input type="text" class="form-control form-control-lg form-control-solid"
                                        placeholder="Address" name="address" wire:model.live="address" />
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-0 fv-row">
                                    <label for="confirmemailpassword" class="mb-3 form-label fs-6 fw-bold">Confirm
                                        Password</label>
                                    <input type="password" name="current_password"
                                        class="form-control form-control-lg form-control-solid"
                                        wire:model.live="current_password" />
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex">
                            <button type="submit" class="px-6 btn btn-primary me-2" wire:loading.attr='disabled'
                                wire:target="updateAddressSubmit">
                                <span wire:loading.remove wire:target="updateAddressSubmit">Update Address</span>
                                <span wire:loading wire:target="updateAddressSubmit">
                                    Please wait... <span
                                        class="align-middle spinner-border spinner-border-sm ms-2"></span>
                                </span>
                            </button>
                            <button type="button" class="px-6 btn btn-color-gray-500 btn-active-light-primary"
                                wire:click="changeAddress">Cancel</button>
                        </div>
                    </form>
                    
                </div>
                

                
                <div class="ms-auto" :class="showFormAddress ? 'd-none' : ''">
                    <button class="btn btn-light btn-active-light-primary" wire:click="changeAddress">Change
                        Address</button>
                </div>
                
            </div>

            <div class="my-6 separator separator-dashed"></div>
            <?php if (isset($component)) { $__componentOriginala665a74688c74e9ee80d4fedd2b98434 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala665a74688c74e9ee80d4fedd2b98434 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-message','data' => ['class' => 'text-success me-3','on' => 'email-update']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-success me-3','on' => 'email-update']); ?>
                <?php echo e(__('Email Address is updated successfully.')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $attributes = $__attributesOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $component = $__componentOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__componentOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala665a74688c74e9ee80d4fedd2b98434 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala665a74688c74e9ee80d4fedd2b98434 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-message','data' => ['class' => 'text-success me-3','on' => 'phone-update']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-success me-3','on' => 'phone-update']); ?>
                <?php echo e(__('Phone Number is updated successfully.')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $attributes = $__attributesOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $component = $__componentOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__componentOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala665a74688c74e9ee80d4fedd2b98434 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala665a74688c74e9ee80d4fedd2b98434 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-message','data' => ['class' => 'text-success me-3','on' => 'address-update']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-success me-3','on' => 'address-update']); ?>
                <?php echo e(__('Address is updated successfully.')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $attributes = $__attributesOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $component = $__componentOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__componentOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
            
            <!--[if BLOCK]><![endif]--><?php if(!Auth::user()->hasVerifiedEmail()): ?>
                
                <div class="p-6 border border-dashed rounded notice d-flex bg-light-warning border-warning">
                    <i class="ki-duotone ki-information fs-2tx text-warning me-4"><span class="path1"></span><span
                            class="path2"></span><span class="path3"></span></i>

                    
                    <div class="flex-wrap d-flex flex-stack flex-grow-1 flex-md-nowrap">
                        
                        <div class="mb-3 mb-md-0 fw-semibold">
                            <h4 class="text-gray-900 fw-bold">Email Not Verified!</h4>

                            <div class="text-gray-700 fs-6 pe-7">Your email is not verified. To verify, please click
                                the
                                verify button
                            </div>
                        </div>
                        

                        
                        <button class="px-6 btn btn-primary align-self-center text-nowrap"
                            wire:click="sendVerification" wire:loading.attr='disabled'
                            wire:target="sendVerification">
                            <span wire:loading.remove wire:target="sendVerification">Verify</span>
                            <span wire:loading wire:target="sendVerification">
                                Please wait... <span class="align-middle spinner-border spinner-border-sm ms-2"></span>
                            </span>

                        </button>
                        
                    </div>
                    
                </div>
                <!--[if BLOCK]><![endif]--><?php if(session('status') == 'verification-link-sent'): ?>
                    <div class="mt-3 mb-4 text-center fw-medium text-success">
                        <?php echo e(__('A new verification link has been sent to the email address')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
        
    </div>
    
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/profile/profile_contact.blade.php ENDPATH**/ ?>