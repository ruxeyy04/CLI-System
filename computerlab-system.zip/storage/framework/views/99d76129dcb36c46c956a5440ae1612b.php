<?php if (isset($component)) { $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772 = $attributes; } ?>
<?php $component = App\View\Components\AssistantLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('assistant-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AssistantLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_content_container" class="app-container container-xxl ">
        <div class="row gx-5 gx-xl-10 mb-xl-10">
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <div class="card">
                    <div class="pt-6 border-0 card-header">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="text-gray-900 card-label fw-bold">Cpu Temperature Logs</span>
                        </h3>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.cputablesearch', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                    <div class="py-4 card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.cputable', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <div class="card">
                    <div class="pt-6 border-0 card-header">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="text-gray-900 card-label fw-bold">Cpu Utilization Logs</span>
                        </h3>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.cputableutilsearch', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                    <div class="py-4 card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.cputableutil', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row gx-5 gx-xl-10 mb-xl-10">
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <div class="card">
                    <div class="pt-6 border-0 card-header">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="text-gray-900 card-label fw-bold">Gpu Temperature Logs</span>
                        </h3>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.gputabletempsearch', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                    <div class="py-4 card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.gputabletemp', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-6 mb-xl-0">
                <div class="card">
                    <div class="pt-6 border-0 card-header">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="text-gray-900 card-label fw-bold">Gpu Usage Logs</span>
                        </h3>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.gputableutilsearch', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                    <div class="py-4 card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.gputableutil', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row gx-5 gx-xl-10 mb-xl-10">
            <div class="mb-5 col-lg-12 col-xl-12 col-xxl-12 mb-xl-0">
                <div class="card">
                    <div class="pt-6 border-0 card-header">
                        <h3 class="card-title align-items-start flex-column">
                            <span class="text-gray-900 card-label fw-bold">RAM Usage Logs</span>
                        </h3>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.ramtablesearch', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                    <div class="py-4 card-body">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.devicelogs.ramtable', ['device' => $device]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="pt-6 border-0 card-header">
                <h3 class="card-title align-items-start flex-column">
                    <span class="text-gray-900 card-label fw-bold">Device Notification/Input Logs</span>
                </h3>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.notifications.search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-10', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
            <div class="py-4 card-body">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.notifications.table', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3964247047-11', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $attributes = $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $component = $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/devicelogs.blade.php ENDPATH**/ ?>