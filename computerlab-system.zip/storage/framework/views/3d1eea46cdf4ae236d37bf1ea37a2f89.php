<div class="gap-2 d-flex align-items-center gap-lg-3">
    <!--begin::Filter menu-->
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() == 'dashboard'): ?>
    
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--end::Filter menu-->
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/breadcrumbs/filteraction.blade.php ENDPATH**/ ?>