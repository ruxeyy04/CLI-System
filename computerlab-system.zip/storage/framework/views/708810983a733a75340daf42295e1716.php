<?php

use App\Livewire\Actions\Logout;
use Livewire\Volt\Component;

new class extends Component
{
    /**
     * Log the current user out of the application.
     */
    public function logout(Logout $logout): void
    {
        $logout();

        $this->redirect('/', navigate: true);
    }
}; ?>


<div class="app-sidebar-footer flex-column-auto pt-2 pb-6 px-6" id="kt_app_sidebar_footer">
    <button  class="btn btn-flex flex-center btn-custom btn-primary overflow-hidden text-nowrap px-0 h-40px w-100" wire:click="logout">

        <span class="btn-label" >
            Logout
        </span>

    </button>
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/components/side-bar/footer.blade.php ENDPATH**/ ?>