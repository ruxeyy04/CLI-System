<?php

use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Volt\Component;

?>

<div>
    <div class="w-lg-500px p-10">
        <form class="form w-100" wire:submit.prevent="resetPassword">
            <div class="text-center mb-10">
                <h1 class="text-gray-900 fw-bolder mb-3">Setup New Password</h1>
                <div class="text-gray-500 fw-semibold fs-6">
                    Already reset the password?
                    <a href="<?php echo e(route('login')); ?>" class="link-primary fw-bold" wire:navigate>Sign in</a>
                </div>
            </div>

            <!-- Email (readonly) -->
            <div class="fv-row mb-8">
                <input type="email" placeholder="Email" name="email" autocomplete="off"
                    class="form-control bg-transparent" wire:model="email" required readonly>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Password -->
            <div class="fv-row mb-8">
                <input type="password" placeholder="Password" name="password" autocomplete="off"
                    class="form-control bg-transparent" wire:model="password" oninput="updateStrengthMeter()">

                <!-- Password Strength Meter -->
                <div class="d-flex align-items-center my-3">
                    <div id="strength-1" class="flex-grow-1 bg-secondary rounded h-5px me-2"></div>
                    <div id="strength-2" class="flex-grow-1 bg-secondary rounded h-5px me-2"></div>
                    <div id="strength-3" class="flex-grow-1 bg-secondary rounded h-5px me-2"></div>
                    <div id="strength-4" class="flex-grow-1 bg-secondary rounded h-5px"></div>
                </div>

                <div class="text-muted">Use 8 or more characters with a mix of letters, numbers & symbols.</div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="fv-plugins-message-container invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <!-- Confirm Password -->
            <div class="fv-row mb-8">
                <input type="password" placeholder="Repeat Password" name="password_confirmation" autocomplete="off"
                    class="form-control bg-transparent" wire:model="password_confirmation">
            </div>

            <div class="d-grid mb-10">
                <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                    <span wire:loading.remove class="indicator-label">Submit</span>
                    <span wire:loading>
                        Please wait... <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function updateStrengthMeter() {
        const password = document.querySelector('input[name="password"]').value;
        const meterBars = [1, 2, 3, 4].map(num => document.getElementById(`strength-${num}`));

        let strength = 0;
        if (password.length >= 8) strength++;
        if (/[a-z]/.test(password)) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[\W]/.test(password)) strength++;

        meterBars.forEach((bar, index) => {
            bar.classList.toggle('bg-success', index < strength);
            bar.classList.toggle('bg-secondary', index >= strength);
        });
    }
</script><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/pages/auth/reset-password.blade.php ENDPATH**/ ?>