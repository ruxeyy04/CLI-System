<?php if (isset($component)) { $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772 = $attributes; } ?>
<?php $component = App\View\Components\AssistantLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('assistant-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AssistantLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div id="kt_app_content_container" class="app-container container-xxl ">
        <!--begin::Card-->
        <div class="mb-4 card">
            <div class="py-3 border-0 card-header">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.search', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4211691807-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.card-toolbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4211691807-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.card-list', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4211691807-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.add-modal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4211691807-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.edit-modal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4211691807-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.laboratory.viewmodal', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4211691807-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $attributes = $__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__attributesOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772)): ?>
<?php $component = $__componentOriginaldb11e7484f7a0644b289dbae1b0f2772; ?>
<?php unset($__componentOriginaldb11e7484f7a0644b289dbae1b0f2772); ?>
<?php endif; ?>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/laboratory.blade.php ENDPATH**/ ?>