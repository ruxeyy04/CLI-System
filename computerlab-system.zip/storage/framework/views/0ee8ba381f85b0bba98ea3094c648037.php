<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\Validation\ValidationException;
use Livewire\Volt\Component;
use Livewire\Attributes\Validate;

?>

<div class="mb-5 card mb-xl-10">
    
    <div class="border-0 cursor-pointer card-header" role="button" data-bs-toggle="collapse"
        data-bs-target="#contactInfoContainer">
        <div class="m-0 card-title">
            <h3 class="m-0 fw-bold">Update Password</h3>
        </div>
    </div>
    

    
    <div id="contactInfoContainer" class="collapse show">
        
        <div class="card-body border-top p-9">
            
            <div class="flex-wrap d-flex align-items-center" x-data="{ showForm: <?php if ((object) ('showForm') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showForm'->value()); ?>')<?php echo e('showForm'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showForm'); ?>')<?php endif; ?> }">
                
                <div :class="showForm ? 'd-none' : ''">
                    <div class="mb-1 fs-6 fw-bold">Password</div>
                    <div class="text-gray-600 fw-semibold">************</div>
                </div>
                

                
                <div :class="showForm ? '' : 'd-none'" class="flex-row-fluid">
                    
                    <form class="form fv-plugins-bootstrap5 fv-plugins-framework" wire:submit="updatePassword">
                        <div class="mb-1 row">
                            <div class="col-lg-4">
                                <div class="mb-0 fv-row fv-plugins-icon-container">
                                    <label for="current_password" class="mb-3 form-label fs-6 fw-bold">Current
                                        Password</label>
                                    <input type="password" class="form-control form-control-lg form-control-solid "
                                        name="current_password" id="current_password"
                                        wire:model="current_password">
                                    <div class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="mb-0 fv-row fv-plugins-icon-container">
                                    <label for="password" class="mb-3 form-label fs-6 fw-bold">New Password</label>
                                    <input type="password" class="form-control form-control-lg form-control-solid "
                                        name="password" id="password" wire:model="password">
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4">
                                <div class="mb-0 fv-row fv-plugins-icon-container">
                                    <label for="password_confirmation" class="mb-3 form-label fs-6 fw-bold">Confirm New
                                        Password</label>
                                    <input type="password" class="form-control form-control-lg form-control-solid "
                                        name="password_confirmation" id="password_confirmation"
                                        wire:model="password_confirmation">
                                    <div
                                        class="fv-plugins-message-container fv-plugins-message-container--enabled invalid-feedback">
                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mb-5 form-text">Password must be at least 8 character and contain symbols</div>

                        <div class="d-flex">
                            <button id="kt_password_submit" type="submit" class="px-6 btn btn-primary me-2"
                                wire:loading.attr='disabled' wire:target="updatePassword">
                                <span wire:loading.remove wire:target="updatePassword">Update Password</span>
                                <span wire:loading wire:target="updatePassword">
                                    Please wait... <span
                                        class="align-middle spinner-border spinner-border-sm ms-2"></span>
                            </button>
                            <button id="kt_password_cancel" type="button"
                                class="px-6 btn btn-color-gray-500 btn-active-light-primary"
                                wire:click="changePassword">Cancel</button>
                        </div>
                    </form>
                    
                </div>
                

                
                <div class="ms-auto" :class="showForm ? 'd-none' : ''">
                    <button class="btn btn-light btn-active-light-primary" wire:click="changePassword">Change
                        Password</button>
                </div>
                
            </div>
            

            
            <div class="my-6 separator separator-dashed"></div>
            
            <?php if (isset($component)) { $__componentOriginala665a74688c74e9ee80d4fedd2b98434 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala665a74688c74e9ee80d4fedd2b98434 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-message','data' => ['class' => 'text-success me-3','on' => 'password-updated']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-success me-3','on' => 'password-updated']); ?>
                <?php echo e(__('Password is updated successfully.')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $attributes = $__attributesOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__attributesOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala665a74688c74e9ee80d4fedd2b98434)): ?>
<?php $component = $__componentOriginala665a74688c74e9ee80d4fedd2b98434; ?>
<?php unset($__componentOriginala665a74688c74e9ee80d4fedd2b98434); ?>
<?php endif; ?>
        </div>
        
    </div>
    
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/profile/change_password.blade.php ENDPATH**/ ?>