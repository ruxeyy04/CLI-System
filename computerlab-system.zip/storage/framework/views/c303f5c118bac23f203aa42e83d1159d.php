<div>
    <div class="table-responsive">
        <table class="table align-middle table-row-dashed fs-6 gy-5" id="table_data_users" wire:ignore.self>
            <thead wire:ignore>
                <tr class="text-start text-muted fw-bold fs-7 text-uppercase gs-0">
                    <th class="w-100px">Device ID</th>
                    <th class="min-w-125px">Name</th>
                    <th class="min-w-125px">Serial Number</th>
                    <th class="min-w-125px">Laboratory</th>
                    <th class="min-w-125px">Patch</th>
                    <th class="min-w-125px">Date Patched</th>
                    <th class="min-w-125px">Added on </th>
                    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
                        <th class="text-end min-w-100px">Actions</th>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </tr>
            </thead>
            <tbody class="text-gray-600 fw-semibold">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if(auth()->user()->laboratory_id != null && ucfirst(auth()->user()->role) === 'Assistant'): ?>
                        <!--[if BLOCK]><![endif]--><?php if($dev->laboratory != null): ?>
                            <?php if(auth()->user()->laboratory_id == $dev->laboratory->id): ?>
                                <tr>
                                    <td><?php echo e($dev->id); ?></td>
                                    <td><?php echo e($dev->device_name); ?></td>
                                    <td><?php echo e($dev->serial_number); ?></td>
                                    <td><?php echo e($dev->laboratory->laboratory_name ?? 'Not Assigned'); ?></td>
                                    <td>
                                        <div
                                            class="badge badge-light-<?php echo e($dev->patch_id ? 'success' : 'danger'); ?> fw-bold">
                                            <?php echo e($dev->patch_id ? 'Patched' : 'Not Patch'); ?></div>
                                    </td>
                                    <td><?php echo e($dev->patched_date ? ($dev->patched_date ? $dev->patched_date->format('d M Y, h:i a') : 'None') : 'None'); ?>

                                    </td>
                                    <td>
                                        <?php echo e($dev->created_at ? $dev->created_at->format('d M Y, h:i a') : 'None'); ?>

                                    </td>
                                    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
                                        <td class="text-end">
                                            <button
                                                class="btn btn-light btn-active-light-primary btn-flex btn-center btn-sm"
                                                data-bs-toggle="dropdown" aria-expanded="false"
                                                wire:key="user-<?php echo e($dev->id); ?>">
                                                Actions
                                                <i class="ki-duotone ki-down fs-5 ms-1"></i>
                                            </button>
                                            <div
                                                class="py-4 dropdown-menu dropdown-menu-end menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-150px">
                                                <!--[if BLOCK]><![endif]--><?php if($dev->patch_id): ?>
                                                    <div class="px-3 menu-item">
                                                        <a href="#" class="px-3 menu-link"
                                                            wire:click="$dispatch('removePatchConfirmation', {'dev_id': '<?php echo e($dev->id); ?>'})">
                                                            Remove Patch
                                                        </a>
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                                <div class="px-3 menu-item">
                                                    <a href="#" class="px-3 menu-link"
                                                        wire:click="$dispatch('openEditDeviceModal', {'dev_id': '<?php echo e($dev->id); ?>'})">
                                                        Edit
                                                    </a>
                                                </div>
                                                <div class="px-3 menu-item">
                                                    <a href="#" class="px-3 menu-link"
                                                        wire:click="$dispatch('deleteDeviceConfirmation', {'dev_id': '<?php echo e($dev->id); ?>'})">
                                                        Delete
                                                    </a>
                                                </div>
                                            </div>

                                        </td>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                </tr>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php else: ?>
                        <tr>
                            <td><?php echo e($dev->id); ?></td>
                            <td><?php echo e($dev->device_name); ?></td>
                            <td><?php echo e($dev->serial_number); ?></td>
                            <td><?php echo e($dev->laboratory->laboratory_name ?? 'Not Assigned'); ?></td>
                            <td>
                                <div class="badge badge-light-<?php echo e($dev->patch_id ? 'success' : 'danger'); ?> fw-bold">
                                    <?php echo e($dev->patch_id ? 'Patched' : 'Not Patch'); ?></div>
                            </td>
                            <td><?php echo e($dev->patched_date ? ($dev->patched_date ? $dev->patched_date->format('d M Y, h:i a') : 'None') : 'None'); ?>

                            </td>
                            <td>
                                <?php echo e($dev->created_at ? $dev->created_at->format('d M Y, h:i a') : 'None'); ?>

                            </td>
                            <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
                                <td class="text-end">
                                    <button class="btn btn-light btn-active-light-primary btn-flex btn-center btn-sm"
                                        data-bs-toggle="dropdown" aria-expanded="false"
                                        wire:key="user-<?php echo e($dev->id); ?>">
                                        Actions
                                        <i class="ki-duotone ki-down fs-5 ms-1"></i>
                                    </button>
                                    <div
                                        class="py-4 dropdown-menu dropdown-menu-end menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-150px">
                                        <!--[if BLOCK]><![endif]--><?php if($dev->patch_id): ?>
                                            <div class="px-3 menu-item">
                                                <a href="#" class="px-3 menu-link"
                                                    wire:click="$dispatch('removePatchConfirmation', {'dev_id': '<?php echo e($dev->id); ?>'})">
                                                    Remove Patch
                                                </a>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                        <div class="px-3 menu-item">
                                            <a href="#" class="px-3 menu-link"
                                                wire:click="$dispatch('openEditDeviceModal', {'dev_id': '<?php echo e($dev->id); ?>'})">
                                                Edit
                                            </a>
                                        </div>
                                        <div class="px-3 menu-item">
                                            <a href="#" class="px-3 menu-link"
                                                wire:click="$dispatch('deleteDeviceConfirmation', {'dev_id': '<?php echo e($dev->id); ?>'})">
                                                Delete
                                            </a>
                                        </div>
                                    </div>

                                </td>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <div class="row">
        <div
            class="col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start dt-toolbar">
            <!-- Add any toolbar items here -->
        </div>
        <div class="col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end">
            <div class="dt-paging paging_simple_numbers">
                <?php echo e($devices->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/device/table.blade.php ENDPATH**/ ?>