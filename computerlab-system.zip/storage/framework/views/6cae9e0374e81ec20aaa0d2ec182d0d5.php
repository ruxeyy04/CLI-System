<?php

use Livewire\Volt\Component;

?>

<div>
    //
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/laboratory/table.blade.php ENDPATH**/ ?>