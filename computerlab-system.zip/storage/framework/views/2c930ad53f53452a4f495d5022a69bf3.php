<div class="modal fade" id="edit_device_modal" tabindex="-1" aria-hidden="true" wire:ignore.self>
    <div class="modal-dialog mw-500px">
        <div class="modal-content">
            <div class="modal-header" id="edit_device_modal_header">
                <h2 class="fw-bold">Update Computer Device</h2>
                <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                    <i class="ki-duotone ki-cross fs-1"><span class="path1"></span><span class="path2"></span></i>
                </div>
            </div>
            <div class="px-5 modal-body my-7">
                <div class="px-5 d-flex flex-column px-lg-10" wire:ignore.self>
                    <form action="">
                        <div class="fv-row mb-7">
                            <label class="mb-2 required fw-semibold fs-6">Device ID <small>(read only)</small></label>
                            <input type="text" name="device_id" class="mb-3 form-control form-control-solid mb-lg-0"
                                placeholder="UUID" wire:model.live='device_id' autocomplete="off" readonly/>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['device_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="fv-row mb-7">
                            <label class="mb-2 required fw-semibold fs-6">Serial Number</label>
                            <input type="text" name="serial_number"
                                class="mb-3 form-control form-control-solid mb-lg-0" placeholder="Serial Number"
                                wire:model.live='serial_number' autocomplete="off" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="fv-row mb-7">
                            <label class="mb-2 required fw-semibold fs-6">Device Name</label>
                            <input type="text" name="device_name"
                                class="mb-3 form-control form-control-solid mb-lg-0" placeholder="Device Name"
                                wire:model.live='device_name' autocomplete="off" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['device_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="fv-row mb-7">
                            <label class="mb-2 required fw-semibold fs-6">Laboratory</label>
                            <div wire:ignore>
                                <select class="lab_select form-select form-select-solid" name="lab_id" data-control="select2"
                                    data-placeholder="Select an option" data-hide-search="true"
                                    wire:model.live="lab_id">
                                    <option></option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $laboratory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lab->id); ?>"><?php echo e($lab->laboratory_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>

                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['lab_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="fv-plugins-message-container invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                    </form>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                    wire:click='discardForm'>Discard</button>
                <button type="button" class="btn btn-primary" wire:click='updateDevice' wire:loading.attr='disabled'
                    wire:target="updateDevice">
                    <span wire:loading.remove wire:target="updateDevice">Update Device</span>
                    <span wire:loading wire:target="updateDevice">
                        Please wait... <span class="align-middle spinner-border spinner-border-sm ms-2"></span>
                    </span>

                </button>
            </div>
        </div>

    </div>
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/device/editmodal.blade.php ENDPATH**/ ?>