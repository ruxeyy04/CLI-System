<div>
    <div class="table-responsive">
        <table class="table align-middle table-row-dashed fs-6 gy-5" id="table_data_users">
            <thead>
                <tr class="text-start text-muted fw-bold fs-7 text-uppercase gs-0">
                    <th class="w-100px">#</th>
                    <th class="min-w-125px">Device Name</th>
                    <th class="min-w-125px">Title</th>
                    <th class="min-w-125px">Message</th>
                    <th class="min-w-125px">Type</th>
                    <th class="min-w-125px">Notified On</th>
                </tr>
            </thead>
            <tbody class="text-gray-600 fw-semibold">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($notification->device->device_name ?? 'N/A'); ?></td>
                        <td><?php echo e($notification->title); ?></td>
                        <td><?php echo e($notification->message); ?></td>
                        <td><?php echo e($notification->type); ?></td>
                        <td><?php echo e($notification->created_at->format('d M Y, h:i A')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No notifications found.</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <!-- Pagination Links -->
    <div class="mt-4">
        <?php echo e($notifications->links()); ?>

    </div>
</div>
<?php /**PATH E:\Web Development\computerlab-system\resources\views/livewire/components/notifications/table.blade.php ENDPATH**/ ?>