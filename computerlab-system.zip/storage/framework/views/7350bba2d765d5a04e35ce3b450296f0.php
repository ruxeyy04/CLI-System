<?php

use Livewire\Volt\Component;
use App\Models\Laboratory;

?>

<div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-5 g-xl-9 d-flex justify-content-center">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $labs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card card-flush h-md-100">
                <!--begin::Card header-->
                <div class="card-header">
                    <!--begin::Card title-->
                    <div class="card-title">
                        <h2><?php echo e($lab->laboratory_name); ?></h2>
                    </div>
                    <!--end::Card title-->
                </div>
                <div class="pt-1 card-body">
                    <div class="mb-5 text-gray-600 fw-bold">Total assistant assign this lab: <?php echo e($lab->users_count); ?>

                    </div>
                    <div class="text-gray-600 d-flex flex-column">
                        <div class="py-2 d-flex align-items-center">
                            <span class="bullet bg-primary me-3"></span>
                            <?php echo e($lab->computer_devices_count); ?>

                            <?php echo e(Str::plural('Computer', $lab->computer_devices_count)); ?>

                        </div>

                        <div class="py-2 d-flex align-items-center">
                            <span class="bullet bg-primary me-3"></span> <?php echo e($lab->capacity); ?> Capacity
                        </div>
                        <div class="py-2 d-flex align-items-center">
                            <span class="bullet bg-primary me-3"></span> Created at
                            <?php echo e($lab->created_at ? $lab->created_at->format('d M Y, h:i a') : 'None'); ?>

                        </div>
                        <div class="py-2 d-flex align-items-center">
                            <span
                                class="bullet bg-primary me-3"></span><?php echo e($lab->updated_at != $lab->created_at ? 'Updated at ' . $lab->updated_at->format('d M Y, h:i a') : 'Not Yet Updated'); ?>

                        </div>
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() != 'dashboard'): ?>
                    <div class="flex-wrap pt-0 card-footer">
                        <button class="my-1 btn btn-light btn-active-primary"
                            wire:click="$dispatch('viewlab_modal', {'lab_id': <?php echo e($lab->id); ?>})">View</button>
                        <button type="button" class="my-1 btn btn-light btn-active-light-primary"
                            wire:click="$dispatch('editlab_modal', {'lab_id': <?php echo e($lab->id); ?>})">Edit</button>
                        <button type="button" class="my-1 btn btn-light btn-active-light-danger"
                            wire:click="$dispatch('delete-lab-confirmation', {'lab_id': <?php echo e($lab->id); ?>})">Delete</button>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/components/laboratory/card-list.blade.php ENDPATH**/ ?>