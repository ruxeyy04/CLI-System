<?php

use Livewire\Attributes\Layout;
use Livewire\Volt\Component;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Events\SessionLogout;

?>

<div id="kt_app_content_container" class="app-container container-xxl">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.profile.usercardheader', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2455823121-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.profile.navitems', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2455823121-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    <!--begin::Login sessions-->
    <div class="mb-5 card mb-lg-10">
        <!--begin::Card header-->
        <div class="card-header">
            <div class="card-title">
                <h3>Login Sessions</h3>
            </div>

            <div class="card-toolbar">
                <div class="my-1 me-4">
                    <!-- Time selection dropdown -->
                    <select wire:model="selectedTime" wire:change='updateSelectedTime'
                        class="form-select form-select-sm form-select-solid w-125px">
                        <option value="0">Select Time</option>
                        <option value="1">1 Hour</option>
                        <option value="6">6 Hours</option>
                        <option value="12">12 Hours</option>
                        <option value="24">24 Hours</option>
                    </select>
                </div>
                <button wire:click="loadAll" class="my-1 btn btn-sm btn-primary">View All</button>
            </div>
        </div>

        <!--begin::Card body-->
        <div class="p-0 card-body">
            <div class="table-responsive">
                <table class="table align-middle table-row-bordered table-row-solid gy-4 gs-9">
                    <thead class="border-gray-200 fs-5 fw-semibold bg-lighten">
                        <tr>
                            <th class="min-w-150px">Device</th>
                            <th class="min-w-100px">IP Address</th>
                            <th class="min-w-100px">Platform Name</th>
                            <th class="min-w-100px">Browser</th>
                            <th class="min-w-100px">User-Agent</th>
                            <th class="min-w-150px">Last Activity</th>
                            <th class="min-w-150px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-6 fw-semibold">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($session->devicefamily ?? 'None'); ?> - <?php echo e($session->devicemodel ?? 'None'); ?></td>
                                <td><span
                                        class="badge badge-light-primary fs-7 fw-bold"><?php echo e($session->ip_address); ?></span>
                                </td>
                                <td><?php echo e($session->platformname); ?></td>
                                <td><?php echo e($session->browsername); ?></td>
                                <td><?php echo e($session->user_agent ?? 'Unknown'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::createFromTimestamp($session->last_activity)->diffForHumans()); ?>

                                </td>
                                <td>
                                    <!--[if BLOCK]><![endif]--><?php if($session->id !== session()->getId()): ?>
                                        <button wire:click="logoutSession('<?php echo e($session->id); ?>')"
                                            class="btn btn-sm btn-danger" wire:loading.attr="disabled" wire:target="logoutSession('<?php echo e($session->id); ?>')">

                                            <span  wire:loading.remove wire:target="logoutSession('<?php echo e($session->id); ?>')">
                                                Logout
                                            </span>
                                            <span wire:loading wire:target="logoutSession('<?php echo e($session->id); ?>')"><span class="align-middle spinner-border spinner-border-sm ms-2"></span> Loading...
                                            </span>
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\Web Development\computerlab-system\resources\views\livewire/pages/profile/sessions.blade.php ENDPATH**/ ?>