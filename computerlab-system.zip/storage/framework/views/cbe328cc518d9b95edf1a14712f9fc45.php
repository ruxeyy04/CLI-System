<?php echo e($slot); ?>

<?php /**PATH E:\Web Development\computerlab-system\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>